/************************************************
* Funcoes da Hashtable  e Lista Ligada dos Jogos
*************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "NEWheader.h"

/* inicializa a hashtable de jogos */
JOGO ** ht_jogos_init(){
	int i;
	JOGO ** ht = malloc(sizeof(JOGO)*TAMANHO_HASHTABLE_MAX);

	for (i = 0; i < TAMANHO_HASHTABLE_MAX; i++)
		ht[i] = NULL;

	return ht;
}

/* inicializar uma lista ligada de jogos */
LISTA * lista_jogos_init(){
	LISTA * nova_lista;
	nova_lista = NULL;
	return nova_lista;
}

/* retorna um ponteiro com um novo jogo */
JOGO * cria_jogo(char * nome, char * equipa1, char * equipa2, int score1, int score2, EQUIPA ** ht){
	JOGO * novo_jogo = malloc(sizeof(JOGO));

	novo_jogo->nome = malloc(sizeof(char *)*(strlen(nome)+1));
	strcpy(novo_jogo->nome, nome);

	novo_jogo->equipa1 = procura_equipa_aux(equipa1, ht);
	novo_jogo->equipa2 = procura_equipa_aux(equipa2, ht);

	novo_jogo->score1 = score1;
	novo_jogo->score2 = score2;

	if (score1 > score2)
		novo_jogo->equipa1->jogos_ganhos++;
	if (score1 < score2)
		novo_jogo->equipa2->jogos_ganhos++;
	
	return novo_jogo;
}

/* adiciona um jogo a lista ligada */
LISTA ** adiciona_jg_lista(LISTA ** lista, JOGO * jogo){
	LISTA * ultimo = * lista;
	LISTA * nova_lista = malloc(sizeof(LISTA));

	nova_lista->jogo = jogo;
	nova_lista->next = NULL;

	if (*lista == NULL)
	{
		*lista = nova_lista;
		return lista;
	}

	while (ultimo->next != NULL)
		ultimo = ultimo->next;

	ultimo->next = nova_lista;

	return lista;
}

/* recebe a hashtable de jogos e imprime-a*/
void imprime_ht_jg(JOGO ** ht){                        /* <<<<-------*/
	JOGO * jogo;
	int i;
	for (i = 0; i < TAMANHO_HASHTABLE_MAX; i++)
	{
		jogo = ht[i];
		printf("[%d]->", i);

		while (jogo != NULL)
		{
			printf("|%s:%s:%s:%d:%d|->", jogo->nome, jogo->equipa1->nome, jogo->equipa2->nome, jogo->score1, jogo->score2);
			jogo = jogo->next;
		}
		printf("NULL\n");
	}
}

/* recebe a lista ligada de jogos e imprime-a*/
void imprime_lista_jg(LISTA * lista){
	LISTA * copia_lista;
	copia_lista = lista;

	printf("[LL]->");
	while (copia_lista != NULL)
	{
		printf("|%s:%s:%s:%d:%d|->", copia_lista->jogo->nome, copia_lista->jogo->equipa1->nome, copia_lista->jogo->equipa2->nome, copia_lista->jogo->score1, copia_lista->jogo->score2);
		copia_lista = copia_lista->next;
	}
	printf("NULL\n");
}


/* devolve um ponteiro para o jogo com o nome dado se existir,
caso contrario devolve NULL*/
JOGO * procura_jogo_aux(char * nome, JOGO ** ht){
	int hash;
	JOGO * jogo;

	hash = funcao_hash(nome, TAMANHO_HASHTABLE_MAX);
	jogo = ht[hash];

	if (jogo == NULL)
		return NULL;

	while (jogo != NULL)
	{
		if (strcmp(jogo->nome, nome) == 0)
			return jogo;
		jogo = jogo->next;
	}
	return NULL;
}


/* apaga um jogo dado da hashtable dos jogos*/
void apaga_jg_ht(JOGO ** ht_jg, JOGO * jogo){
	int hash;
	JOGO * anterior, * node;

	hash = funcao_hash(jogo->nome, TAMANHO_HASHTABLE_MAX);
	node = ht_jg[hash];

	/* quando se apaga o 1o jogo */
	if (node != NULL && strcmp(node->nome, jogo->nome) == 0)
	{
		ht_jg[hash] = ht_jg[hash]->next;
		free(jogo->nome);
		free(jogo);
		/*imprime_ht_jg(ht_jg);*/
		return;
	}

	while (node != NULL && strcmp(node->nome, jogo->nome) != 0)
	{
		anterior = node;
		node = node->next;
	}
	anterior->next = node->next;

	free(jogo->nome);
	free(jogo);
	/*imprime_ht_jg(ht_jg);*/
}


/* apaga um jogo dado da lista ligada de jogos*/
void apaga_jg_lista(LISTA ** lista, JOGO * jogo){
	LISTA * node = * lista, * aux;

	if (node->next == NULL)
		{
			*lista = NULL;
			free(node);
			/*imprime_lista_jg(*lista);*/
			return;
		}

	/* se queremos apagar o primeiro elemento da lista*/
	if (strcmp(node->jogo->nome, jogo->nome) == 0)
	{
		*lista = node->next;
		free(node);
		/*imprime_lista_jg(*lista);*/
		return;
	}

	while (node->next != NULL)
	{
		if (strcmp(node->next->jogo->nome, jogo->nome) == 0)
		{
			aux = node->next;
			node->next = node->next->next;
			free(aux);
			/*imprime_lista_jg(*lista);*/
			return;
		}
		node = node->next;
	}
}

/* liberta a memoria alocada na hashtable dos jogos*/
void destroi_ht_jg(JOGO ** ht_jg){
	int hash = 0;
	JOGO * jogo;

	for (; hash < TAMANHO_HASHTABLE_MAX; hash++)
	{
		while (ht_jg[hash] != NULL)
		{
			jogo = ht_jg[hash];
			ht_jg[hash] = ht_jg[hash]->next;
			free(jogo->nome);
			free(jogo);
		}
	}
}

/* liberta a memoria alocada na lista ligada dos jogos*/
void destroi_lista_jg(LISTA ** lista){
	LISTA * node = * lista, * aux;

	while (node != NULL)
	{
		aux = node;
		node = node->next;
		free(aux);
	}
	free(node);
}

/*void destroi_lista_jg(LISTA ** lista){
	LISTA * node = * lista, * aux;

	while (node != NULL)
	{
		aux = node->next;
		apaga_jg_lista(lista, node->jogo);
		node = aux;
	}

}*/